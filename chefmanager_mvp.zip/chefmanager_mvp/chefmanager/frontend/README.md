# ChefManager Frontend (React + Vite)

## Requisitos
- Node.js 18+

## Ejecutar
```bash
npm install
npm run dev
```

La app asume backend en `http://localhost:8080`.
