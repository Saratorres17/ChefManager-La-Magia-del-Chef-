package com.chefmanager.service;

import com.chefmanager.model.AuditLog;
import com.chefmanager.repository.AuditLogRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuditLogService {
    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void registerAction(String action, String details) {
        AuditLog log = new AuditLog();
        log.setUsername(getCurrentUsername());
        log.setAction(action);
        log.setDetails(details);
        log.setWhenAction(LocalDateTime.now());
        auditLogRepository.save(log);
    }

    private String getCurrentUsername() {
        try {
            Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (principal instanceof UserDetails) {
                return ((UserDetails) principal).getUsername();
            } else {
                return principal.toString();
            }
        } catch (Exception e) {
            return "ANÓNIMO";
        }
    }
}