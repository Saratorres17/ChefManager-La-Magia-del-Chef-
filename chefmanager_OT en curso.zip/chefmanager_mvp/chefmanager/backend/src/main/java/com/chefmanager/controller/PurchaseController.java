package com.chefmanager.controller;

import com.chefmanager.model.Purchase;
import com.chefmanager.service.PurchaseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/ot-en-curso/purchase")
public class PurchaseController {
    private final PurchaseService purchaseService;

    public PurchaseController(PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }

    @GetMapping("/new")
    public String showPurchaseForm(Model model) {
        model.addAttribute("purchase", new Purchase());
        return "purchase-form";
    }

    @PostMapping("/save")
    public String savePurchase(@ModelAttribute("purchase") Purchase purchase) {
        purchaseService.savePurchase(purchase);
        return "redirect:/ot-en-curso/purchase/list";
    }

    @GetMapping("/list")
    public String listPurchases(Model model) {
        model.addAttribute("purchases", purchaseService.getAllPurchases());
        return "purchase-list";
    }
}
