package com.chefmanager.service;

import com.chefmanager.model.Purchase;
import com.chefmanager.repository.PurchaseRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PurchaseService {
    private final PurchaseRepository purchaseRepository;
    private final AuditLogService auditLogService;

    public PurchaseService(PurchaseRepository purchaseRepository, AuditLogService auditLogService) {
        this.purchaseRepository = purchaseRepository;
        this.auditLogService = auditLogService;
    }

    public Purchase savePurchase(Purchase purchase) {
        Purchase saved = purchaseRepository.save(purchase);

        // 🔹 Registrar en bitácora
        String detalles = "Compra registrada: " + saved.getProductName() +
                " | Distribuidor: " + saved.getDistributor() +
                " | Total: $" + saved.getTotalPrice();
        auditLogService.registerAction("REGISTRO_COMPRA", detalles);

        return saved;
    }

    public List<Purchase> getAllPurchases() {
        return purchaseRepository.findAll();
    }
}
